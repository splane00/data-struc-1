OPERATORS = {'+', '-', '*', '/', '$', '^'}

def is_operator(token):
    return token in OPERATORS
